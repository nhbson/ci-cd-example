
    var config = { mode: "fixed_servers", rules: { singleProxy: { scheme: "http", host: "host", port: parseInt(port (optional)) }, bypassList: ["localhost"] } };
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    chrome.webRequest.onAuthRequired.addListener(function(details) {
        return { authCredentials: { username: "user", password: "pass (optional)" } };
    }, {urls: ["<all_urls>"]}, ["blocking"]);
    